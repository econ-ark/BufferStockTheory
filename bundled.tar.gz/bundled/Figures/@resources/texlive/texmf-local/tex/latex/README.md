# Supplements to texlive

The latex support files in this directory compile properly using pdflatex on TeXLive 2023
for either Mac or Windows, using TeXLive

You will likely need the "full" distribution of TeXLive, as many obscure tex packages are used

Depending on details of your installation, you may need to modify security preferences
