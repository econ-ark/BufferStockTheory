# texmf-local contains customizations of LaTeX

CDC private version of texmf-local, used across all systems

